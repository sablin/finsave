window.onload = function(){
	document.querySelector('.cost').onsubmit = function(event){
		event.preventDefault();
		console.log('sss');
		let regexp = /^[АВЕКМНОРСТУХ][0-9]{3}[АВЕКМНОРСТУХ]{2} [0-9]{2,3}/i;
		let carNumber = document.querySelector('.cost-num').value;
		console.log(carNumber);
		console.log(regexp.test(carNumber));
	}



}
//$(".cost-num").mask("a999aa 999 RUS");